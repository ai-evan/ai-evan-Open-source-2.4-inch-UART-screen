//PAGE:0
//PAGE:1
//PAGE:2
//PAGE:3
//PAGE:4
#define  _ICON_PAGE4_icon_1         0x0001
#define  _ICON_PAGE4_icon_2         0x0002
#define  _VARADJ_PAGE4_varAdj_2         0x0002
#define  _VARADJ_PAGE4_varAdj_3         0x0002
//PAGE:5
#define  _ICON_PAGE5_icon_1         0x0003
#define  _ICON_PAGE5_icon_2         0x0002
#define  _VARADJ_PAGE5_varAdj_2         0x0002
#define  _VARADJ_PAGE5_varAdj_3         0x0002
//PAGE:6
#define  _ICON_PAGE6_icon_1         0x0004
#define  _ICON_PAGE6_icon_2         0x0002
#define  _VARADJ_PAGE6_varAdj_2         0x0002
#define  _VARADJ_PAGE6_varAdj_3         0x0002
//PAGE:7
#define  _ICON_PAGE7_icon_1         0x0005
#define  _ICON_PAGE7_icon_2         0x0002
#define  _VARADJ_PAGE7_varAdj_2         0x0002
#define  _VARADJ_PAGE7_varAdj_3         0x0002
//PAGE:8
#define  _ICON_PAGE8_icon_1         0x0006
#define  _ICON_PAGE8_icon_2         0x0002
#define  _VARADJ_PAGE8_varAdj_2         0x0002
#define  _VARADJ_PAGE8_varAdj_3         0x0002
//PAGE:9
#define  _ICON_PAGE9_icon_1         0x0007
#define  _ICON_PAGE9_icon_2         0x0002
#define  _VARADJ_PAGE9_varAdj_2         0x0002
#define  _VARADJ_PAGE9_varAdj_3         0x0002
//PAGE:10
#define  _ICON_PAGE10_icon_1         0x0009
#define  _ICON_PAGE10_icon_2         0x0002
#define  _VARADJ_PAGE10_varAdj_2         0x0002
#define  _VARADJ_PAGE10_varAdj_3         0x0002
//PAGE:11
#define  _ICON_PAGE11_icon_1         0x000B
#define  _ICON_PAGE11_icon_2         0x0002
#define  _VARADJ_PAGE11_varAdj_2         0x0002
#define  _VARADJ_PAGE11_varAdj_3         0x0002
//PAGE:12
#define  _ICON_PAGE12_icon_0         0x000D
#define  _ICON_PAGE12_icon_1         0x000E
#define  _ICON_PAGE12_icon_2         0x000F
#define  _PNGNUMBER_PAGE12_pngNumber_0         0x0100
#define  _PNGNUMBER_PAGE12_pngNumber_1         0x0010
#define  _PNGNUMBER_PAGE12_pngNumber_2         0x0042
#define  _PNGNUMBER_PAGE12_pngNumber_3         0x0043
//PAGE:13
//PAGE:14
#define  _ICON_PAGE14_icon_0         0x0016
#define  _ICON_PAGE14_icon_1         0x0018
#define  _ICON_PAGE14_icon_2         0x001A
#define  _VARADJ_PAGE14_varAdj_2         0x001A
#define  _ICON_PAGE14_icon_3         0x001C
#define  _VARADJ_PAGE14_varAdj_3         0x001C
#define  _ICON_PAGE14_icon_4         0x001E
#define  _VARADJ_PAGE14_varAdj_4         0x001E
#define  _ICON_PAGE14_icon_5         0x0020
#define  _AUTOVAR_PAGE14_autoVar_0         0x0022
#define  _PNGNUMBER_PAGE14_pngNumber_0         0x0023
#define  _PNGNUMBER_PAGE14_pngNumber_1         0x0023
#define  _ICON_PAGE14_icon_8         0x002A
#define  _VARADJ_PAGE14_varAdj_5         0x002A
#define  _ICON_PAGE14_icon_9         0x002C
#define  _VARADJ_PAGE14_varAdj_6         0x002C
#define  _ICON_PAGE14_icon_10         0x002E
#define  _VARADJ_PAGE14_varAdj_7         0x002E
#define  _ICON_PAGE14_icon_11         0x0030
#define  _ICON_PAGE14_icon_12         0x0032
#define  _VARADJ_PAGE14_varAdj_8         0x0028
#define  _VARADJ_PAGE14_varAdj_9         0x0028
#define  _ICON_PAGE14_icon_6         0x0028
#define  _AUTOVAR_PAGE14_autoVar_1         0x0039
#define  _AUTOVAR_PAGE14_autoVar_2         0x0040
//PAGE:15
//PAGE:16
#define  _GIF_PAGE16_gif_0         0x0034
//PAGE:17
#define  _ICON_PAGE17_icon_0         0x0016
#define  _ICON_PAGE17_icon_1         0x0018
#define  _ICON_PAGE17_icon_2         0x001A
#define  _VARADJ_PAGE17_varAdj_2         0x001A
#define  _ICON_PAGE17_icon_3         0x001C
#define  _VARADJ_PAGE17_varAdj_3         0x001C
#define  _ICON_PAGE17_icon_4         0x001E
#define  _VARADJ_PAGE17_varAdj_4         0x001E
#define  _ICON_PAGE17_icon_5         0x0020
#define  _AUTOVAR_PAGE17_autoVar_0         0x0022
#define  _PNGNUMBER_PAGE17_pngNumber_0         0x0023
#define  _PNGNUMBER_PAGE17_pngNumber_1         0x0023
#define  _ICON_PAGE17_icon_8         0x002A
#define  _VARADJ_PAGE17_varAdj_5         0x002A
#define  _ICON_PAGE17_icon_9         0x002C
#define  _VARADJ_PAGE17_varAdj_6         0x002C
#define  _ICON_PAGE17_icon_10         0x002E
#define  _VARADJ_PAGE17_varAdj_7         0x002E
#define  _ICON_PAGE17_icon_11         0x0030
#define  _ICON_PAGE17_icon_12         0x0032
#define  _VARADJ_PAGE17_varAdj_8         0x0035
#define  _VARADJ_PAGE17_varAdj_9         0x0035
#define  _ICON_PAGE17_icon_6         0x0035
#define  _AUTOVAR_PAGE17_autoVar_1         0x0039
#define  _AUTOVAR_PAGE17_autoVar_2         0x0040
//PAGE:18
//PAGE:19
#define  _GIF_PAGE19_gif_0         0x0038
//PAGE:20
#define  _ICON_PAGE20_icon_1         0x0001
#define  _ICON_PAGE20_icon_2         0x0002
#define  _ICON_PAGE20_icon_0         0x0104
#define  _AUTOVAR_PAGE20_autoVar_0         0x0105
//PAGE:21
#define  _ICON_PAGE21_icon_1         0x0003
#define  _ICON_PAGE21_icon_2         0x0002
#define  _ICON_PAGE21_icon_0         0x0104
#define  _AUTOVAR_PAGE21_autoVar_0         0x0105
//PAGE:22
#define  _ICON_PAGE22_icon_1         0x0004
#define  _ICON_PAGE22_icon_2         0x0002
#define  _ICON_PAGE22_icon_0         0x0104
#define  _AUTOVAR_PAGE22_autoVar_0         0x0105
//PAGE:23
#define  _ICON_PAGE23_icon_1         0x0005
#define  _ICON_PAGE23_icon_2         0x0002
#define  _ICON_PAGE23_icon_0         0x0104
#define  _AUTOVAR_PAGE23_autoVar_0         0x0105
//PAGE:24
#define  _ICON_PAGE24_icon_1         0x0006
#define  _ICON_PAGE24_icon_2         0x0002
#define  _ICON_PAGE24_icon_0         0x0104
#define  _AUTOVAR_PAGE24_autoVar_0         0x0105
//PAGE:25
#define  _ICON_PAGE25_icon_1         0x0007
#define  _ICON_PAGE25_icon_2         0x0002
#define  _ICON_PAGE25_icon_0         0x0104
#define  _AUTOVAR_PAGE25_autoVar_0         0x0105
//PAGE:26
#define  _ICON_PAGE26_icon_1         0x0009
#define  _ICON_PAGE26_icon_2         0x0002
#define  _ICON_PAGE26_icon_0         0x0104
#define  _AUTOVAR_PAGE26_autoVar_0         0x0105
//PAGE:27
#define  _ICON_PAGE27_icon_1         0x000B
#define  _ICON_PAGE27_icon_2         0x0002
#define  _ICON_PAGE27_icon_0         0x0104
#define  _AUTOVAR_PAGE27_autoVar_0         0x0105
