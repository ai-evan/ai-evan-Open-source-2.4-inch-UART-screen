//PAGE:0
#define  _GIF_PAGE0_gif_0         0x0000
//PAGE:1
#define  _GIF_PAGE1_gif_0         0x0001
